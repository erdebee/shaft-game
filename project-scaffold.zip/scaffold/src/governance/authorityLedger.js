/**
 * authorityLedger.js
 * Tracks standing with each power base — Board, Security, Engineering, Deep
 * Levels, general population. Authority is spent by ruling against a faction
 * and earned by delivering for one. Reaching zero with Security is fatal.
 */

export function spend(state, faction, amount, reason) {
  // TODO
}

export function earn(state, faction, amount, reason) {
  // TODO
}

export function canCompel(state, faction) {
  // TODO: below a threshold, orders are ignored rather than refused
}
