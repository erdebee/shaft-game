/**
 * gameState.js
 * The single serialisable state container. Everything the save system writes
 * and the config resolver seeds lives here. Systems read and mutate through
 * their own modules rather than reaching in arbitrarily.
 */

export function createGameState({ chapter, config, seed }) {
  return {
    meta: { chapter, seed, version: 1, createdAt: Date.now() },
    clock: null,
    population: {},      // headcount, cohorts, morale, unrest
    resources: {},       // stocks and flows, see systems/resources
    infrastructure: {},  // levels, buildings, condition
    governance: {},      // Accord articles, precedent, authority ledger
    narrative: {},       // flags, revelation state, board relations
    log: [],             // player-visible history of decisions and events
  };
}

export function snapshot(state) {
  return structuredClone(state);
}
