/**
 * clock.js
 * Owns simulation time. Real-time advance with pause, speed multipliers,
 * and the decision-window boundaries that gate Board sessions and dilemmas.
 */

export const SPEEDS = { PAUSED: 0, NORMAL: 1, FAST: 3, VERY_FAST: 10 };

export function createClock({ tickMs = 1000, startTick = 0 } = {}) {
  return {
    tick: startTick,
    tickMs,
    speed: SPEEDS.NORMAL,
    accumulator: 0,
  };
}

/** Advance the clock by real elapsed ms. Returns how many sim ticks elapsed. */
export function advance(clock, deltaMs) {
  // TODO: accumulate deltaMs * speed, emit tick boundaries
  return 0;
}

/** True when this tick closes a decision window (Board session, shift change). */
export function isDecisionBoundary(clock) {
  // TODO: derive from config (ticksPerDecisionWindow)
  return false;
}
