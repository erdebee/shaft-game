/**
 * engine.js
 * The game loop. Drives systems in a fixed order each tick so results are
 * deterministic under a fixed seed — required for headless fast-forward
 * and for reproducing playtest reports.
 */

import { advance, isDecisionBoundary } from './clock.js';
import { emit } from './eventBus.js';

const SYSTEM_ORDER = [
  'power',        // decide what is energised before anything consumes
  'resources',    // extraction and conversion
  'water',
  'airQuality',
  'haulage',      // move what was produced
  'buildings',    // condition, wear, output modifiers
  'population',   // consumption, morale, unrest
  'governance',   // statute effects, enforcement
  'narrative',    // dilemmas, scheduled events, revelation staging
];

export function createEngine(state, systems) {
  return { state, systems, running: false, rafId: null };
}

export function start(engine) {
  // TODO: requestAnimationFrame loop calling step()
}

export function stop(engine) {
  // TODO
}

/** One simulation tick. Pure with respect to state + seeded RNG. */
export function step(engine, deltaMs) {
  const ticks = advance(engine.state.clock, deltaMs);
  for (let i = 0; i < ticks; i++) {
    for (const name of SYSTEM_ORDER) {
      engine.systems[name]?.tick(engine.state);
    }
    if (isDecisionBoundary(engine.state.clock)) {
      emit('decision:window', { tick: engine.state.clock.tick });
    }
  }
}

/** Run N ticks with no rendering. Used by balance tooling. */
export function fastForward(engine, tickCount) {
  // TODO
}
