/**
 * router.js
 * Screen switching. No history API — this is an application shell, not pages.
 */
export function register(name, screen) { /* TODO */ }
export function go(name) { /* TODO */ }
