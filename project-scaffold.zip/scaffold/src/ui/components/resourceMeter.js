/** Stock level with trend arrow and time-to-empty at the current rate. */
export function render(stock, flow) { /* TODO */ }
