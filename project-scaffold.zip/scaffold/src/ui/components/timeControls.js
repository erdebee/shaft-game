/** Pause, speed selection, and the current decision-window indicator. */
export function mount(root, clock) { /* TODO */ }
