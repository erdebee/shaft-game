/** Scrolling record of decisions and events. The player's own paper trail. */
export function append(entry) { /* TODO */ }
