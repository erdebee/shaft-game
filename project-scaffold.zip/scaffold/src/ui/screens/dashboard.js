/**
 * dashboard.js
 * The default screen: settlement status at a glance. Stocks and flows,
 * warnings, and the current decision window.
 */
export function mount(root, state) { /* TODO */ }
export function update(state) { /* TODO */ }
