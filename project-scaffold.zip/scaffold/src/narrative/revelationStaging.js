/**
 * revelationStaging.js
 * Controls how and when a truth reaches an audience. The same fact can be
 * released four ways — full disclosure, partial, deflection, suppression —
 * and each moves doubt and favour differently across factions.
 *
 * Doubt is sticky: it decays far more slowly than favour, so repeated
 * suppression is survivable in the short run and corrosive over a chapter.
 */

export const FRAMINGS = ['disclose', 'partial', 'deflect', 'suppress'];

export function stage(state, { truthId, framing, audience }) {
  // TODO: apply doubt/favour deltas, schedule delayed leak risk
}

export function leakRisk(state, truthId) {
  // TODO: rises with how many people know and how long it has been held
}
