/**
 * schema.js
 * Declares the shape and legal range of every tunable parameter, and validates
 * each config layer on load. Catches typos in override files before they
 * become an unexplained balance shift three hours into a playtest.
 */

export const SCHEMA = {
  // 'power.reactorOutputPerTick': { type: 'number', min: 0, max: 10000 },
  // TODO: populate from the systems reference document
};

/** @returns {{ok: boolean, errors: string[]}} */
export function validate(layer, layerName) {
  const errors = [];
  // TODO: unknown-key detection, type check, range check
  return { ok: errors.length === 0, errors };
}
