/**
 * configLoader.js
 * Resolves the layered configuration:
 *   base -> chapter/difficulty -> silo profile -> mission -> event -> sandbox
 * Later layers override earlier ones key by key. Every resolved value keeps a
 * record of which layer supplied it, so the diff export can show what a
 * playtest build actually ran with.
 */

import { validate } from './schema.js';

export const LAYER_ORDER = ['base', 'chapter', 'silo', 'mission', 'event', 'sandbox'];

/** Deep-merge layers in LAYER_ORDER, recording provenance per key. */
export function resolve(layers) {
  const resolved = {};
  const provenance = {};
  // TODO: flatten each layer to dot-paths, apply in order, record source
  return { resolved, provenance };
}

export async function loadLayer(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Config layer not found: ${path}`);
  return res.json();
}

/** Re-read layers and re-resolve without restarting the run. */
export async function hotReload(currentConfig, paths) {
  // TODO: reload, validate, emit 'config:reloaded' with a diff
}
