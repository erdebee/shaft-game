/**
 * saveLoad.js
 * Serialises gameState to localStorage or a downloadable file. Saves record
 * the run seed and the resolved config hash, so a bug report reproduces.
 */

const KEY_PREFIX = 'save:';

export function save(state, slot) {
  // TODO: serialise, version-stamp, write
}

export function load(slot) {
  // TODO: read, migrate if version is older, return state
}

export function listSlots() {
  // TODO
  return [];
}

export function migrate(raw) {
  // TODO: forward-migrate old saves rather than rejecting them
}
