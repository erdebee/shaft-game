/** Display formatting. Keep unit strings in one place so the UI stays consistent. */

export function quantity(value, unit) {
  // TODO
  return `${value} ${unit}`;
}

export function tickToDate(tick, config) {
  // TODO: in-world calendar
}
