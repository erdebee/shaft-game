/**
 * main.js
 * Entry point. Loads config, builds state, wires systems into the engine,
 * mounts the UI, and starts the loop.
 */

import { createEngine, start } from './core/engine.js';
import { createGameState } from './core/gameState.js';
import { createClock } from './core/clock.js';
import { resolve, loadLayer } from './config/configLoader.js';
import { createStream } from './config/rng.js';

async function boot({ chapter = 1, seed = Date.now() } = {}) {
  const base = await loadLayer('./resources/data/config/base.json');
  const chapterLayer = await loadLayer(`./resources/data/config/chapter${chapter}.json`);
  const { resolved } = resolve({ base, chapter: chapterLayer });

  const state = createGameState({ chapter, config: resolved, seed });
  state.clock = createClock();

  const streams = {
    narrative: createStream(seed, 'narrative'),
    economy: createStream(seed, 'economy'),
    events: createStream(seed, 'events'),
  };

  // TODO: instantiate systems, register UI screens
  const engine = createEngine(state, {});
  start(engine);

  return { engine, streams };
}

boot().catch((err) => {
  console.error('Boot failed:', err);
});
