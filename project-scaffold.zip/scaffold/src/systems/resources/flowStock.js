/**
 * flowStock.js
 * Generic stock-and-flow accounting. A stock holds a quantity with a cap; a
 * flow moves quantity per tick. Shortfalls are reported rather than silently
 * clamped, because who goes without is a governance decision, not a maths one.
 */

export function createStock(id, { capacity, initial = 0 }) {
  return { id, capacity, amount: initial };
}

/** Apply inflows and outflows for one tick. Returns unmet demand by consumer. */
export function settle(stock, inflows, demands) {
  // TODO: total inflow, cap at capacity (report spill), allocate against demand
  return { shortfall: {}, spill: 0 };
}
