/**
 * buildingRegistry.js
 * Loads building definitions from resources/data/buildings.json and tracks
 * placed instances: level, condition, staffing, and current output modifier.
 */

export function tick(state) {
  // TODO: wear, maintenance draw, output scaling by condition and staffing
}

export function place(state, buildingId, level) {
  // TODO: validate level constraints (some buildings are depth-restricted)
}
