/**
 * haulageMethods.js
 * Vertical movement between levels. Each method (porter, winch, lift, pneumatic)
 * has throughput, power draw, labour cost and failure modes. Distance is the
 * core constraint of the settlement: everything is above or below something.
 */

export function tick(state) {
  // TODO: resolve transport queues against available capacity per shaft
}

export function throughput(methodId, fromLevel, toLevel, config) {
  // TODO
}
