/**
 * priorityLadder.js
 * When generation falls short of draw, this decides what stays lit. The ladder
 * is not hardcoded — it is an Accord article, so the player can rewrite it and
 * live with the result. Changing it mid-crisis is one of the sharper dilemmas.
 */

export function tick(state) {
  // TODO: sum generation, sum draw by tier, brown out from the bottom up
}

export function currentLadder(state) {
  // TODO: read from governance (statute), fall back to config default
  return [];
}
