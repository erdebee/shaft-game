# Untitled Project

A browser-based survival and management simulation set in a sealed underground
settlement governed by layered deception. The player manages physical
infrastructure and writes the law that governs it — and discovers, chapter by
chapter, who is actually in charge.

**Status:** pre-implementation. This repository is structure and stubs.

## Running it

No build step. Native ES modules, served over HTTP (modules will not load from
`file://`):

```
npm run serve     # or: python3 -m http.server 8000
```

Then open `http://localhost:8000`.

`package.json` carries no dependencies. It exists so Node's test runner treats
`.js` files as ES modules, matching how the browser loads them.

```
npm test          # node --test
```

## Layout

```
concept/          design documents — the source of truth for intent
src/
  core/           game loop, state container, event bus, clock
  config/         layered config resolution, schema, seeded RNG
  systems/        the physical simulation
  governance/     the Accord, Core Mandate, precedent, Apocrypha
  narrative/      dilemmas, revelation staging, Board relations
  chapters/       per-chapter logic and plot mechanics
  ui/             screens, components, styles
  save/           serialisation and migration
  utils/
resources/
  data/           all content as JSON — parameters, statutes, dilemmas, roster
  assets/         images, audio, icons, fonts
tests/
```

## Architecture rules

These are the constraints the structure is built to protect. Breaking one is a
decision worth making explicitly, not by accident.

**Content is data, not code.** Every number, statute, dilemma and Board member
lives in `resources/data/` as JSON. If a balance change requires editing a file
in `src/`, something is in the wrong place.

**Configuration is layered, never hardcoded.** Values resolve through
`base → chapter → silo → mission → event → sandbox`, each layer overriding the
last key by key, with provenance recorded so a playtest report can name which
layer supplied which value. `config/schema.js` validates every layer on load.

**Determinism is a requirement, not a nicety.** Nothing calls `Math.random()`.
Every random draw comes from a named seeded stream in `config/rng.js`, so
adding a draw in the narrative code cannot shift the economy's sequence. This is
what makes headless fast-forward and reproducible bug reports possible.

**Systems tick in a fixed order.** `core/engine.js` defines it. Systems talk to
each other through the event bus, not by importing each other.

**Chapter-specific plot mechanics stay in their chapter.** `nexusChannel.js` and
`presidiumCoup.js` live under `chapters/chapter2/` because they are that
chapter's plot, not reusable infrastructure.

**Chapter 3 is not in this scaffold.** It is documented as vision only and
excluded from v1 on purpose.

## The one thread to be careful with

The scrubber catalyst has no local production recipe, and that is deliberate.
It is seeded as an unexplained external supply in Chapter 1 and becomes the
Presidium's leverage in Chapter 2, when cutting it off demonstrates dependency
without a shot fired. `resources/data/resources/components.json` marks it
`producibleLocally: false`. Changing that is a narrative decision, not a
balance tweak.

## Terminology

| Term | Meaning |
| --- | --- |
| The Accord | The amendable law document |
| The Advisory Board | The governing council |
| The Chair | The true hidden authority behind the Board |
| The Apocrypha | The restricted archive chamber |
| The Nexus | The covert external directive channel |
| The Core Mandate | Pre-existing doctrine; bounds what the Accord may say |
| The Presidium | The central controlling settlement |
| The Coryphaeus | Head of the Presidium |

## Next

1. Implement `config/configLoader.js` — the layered resolver underpins
   playtesting and per-silo tuning, so it comes before simulation work.
2. Populate `config/schema.js` from the systems reference document.
3. Build `systems/resources/flowStock.js` and get one resource cycling end to
   end before adding the rest.
4. Set the visual direction, then fill `ui/styles/tokens.css`.
